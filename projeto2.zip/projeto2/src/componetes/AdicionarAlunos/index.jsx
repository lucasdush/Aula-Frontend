import './style.css'
import { useState } from 'react'

export default function AdicionarAlunos(){
   
  //criando variaveis  
    const [nome, setNome]= useState('')
    const [email,setEmail]= useState('')

//criando lista de alunos

        const [ listaAlunos, setListaAlunos]= useState([])

//função para adicionar alunos na lista

        const addAluno = (event) => {
            //evite que a pagina seja carregada pelo aluno
            event.preventDefault()
            if(nome && email){
                //add os dados anteriores novos
                setListaAlunos([...listaAlunos,{nome, email}])
                setNome('')
                setEmail('')
            }
        }

    return(
        <div> Adicionar aluno   
        <form onSubmit={addAluno}>
        <input
            type="nome"
            placeholder="Nome"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
        />
         <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
         />
            <button type="submit">Adicionar</button>
        </form>

     <hr/> 
     <h2>Matriculados</h2>

     <ul>
        {listaAlunos.map((aluno, index) => (
            <li key={index}>{aluno.nome} - {aluno.email} </li>
        ))}
     </ul>



        </div>
    )
}