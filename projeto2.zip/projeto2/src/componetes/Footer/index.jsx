import './style.css'

export default function (){
    return (
        <footer className="container">
            <p>
            
                &copy;{new Date().getFullYear()} - Direitos e Deveres
                <br/> LucasImportsLTDA.
            </p>
        </footer>
    )
}

