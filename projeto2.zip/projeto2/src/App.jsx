import './App.css'
import Footer from './componetes/Footer'
import Header from './componetes/Header'
import AdicionarAlunos from './componetes/AdicionarAlunos'  
function App() {


  return (
    <>
    <Header/>
   <h1>Front Ensino</h1>
   <AdicionarAlunos/>
    <Footer/>
    </>
  )
}

export default App
