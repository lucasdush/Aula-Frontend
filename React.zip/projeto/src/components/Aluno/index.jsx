import './style.css'

export default function Aluno(){
   
    return(
        <div classeName='aluno'>
            <h2>Dados do Aluno</h2>
            <p><strong>Nome:</strong> Lucas Xavier </p>
            <p><strong>Email</strong> lucasdush@gmail.com </p>
            <p><strong>CPF</strong> 654121341685 </p>



        </div>
    )
}