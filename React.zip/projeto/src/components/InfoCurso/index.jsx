import { useState } from 'react';
import './style.css'

export default function InfoCurso() {
    const [nome, setNome] = useState('Desenvolvimento de Sistemas');
    
    return (
        <div className='info-curso'>
            <h2>Dados do curso</h2>
            <p><strong>Nome:</strong> $( nome )</p>
            <p><strong>Carga Horaria</strong> 158 horas </p>
            <p><strong>Local</strong>Senai</p>
       
       
       
        </div>
    );
}