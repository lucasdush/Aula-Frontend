
import './App.css'
import Aluno from './components/Aluno'
import InfoCurso from './components/InfoCurso'
import Mensagem from './components/Mensagem'

function App() {
  

  return (
    //html
    <>
     <h1>Lucas Dush</h1>
     <h4>Lucas Dush</h4>
     <Aluno></Aluno>

      <Mensagem/>
      <InfoCurso />
    </>
  )
}

export default App
